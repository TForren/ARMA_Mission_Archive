
class CfgSounds
{
	sounds[] = 
	{
	};


	class anthem
	{
		name="anthem";
		sound[]={"sounds\anthem.ogg",db+5,1.0};
		titles[]={};
	};
	
		class march1
	{
		name="march1";
		sound[]={"sounds\march1a.ogg",db+5,1.0};
		titles[]={};
	};

};


